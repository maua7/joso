# SIMPLES D+ Contabilidade - Réplica de Layout

Este projeto é uma réplica do layout do site da SIMPLES D+ Contabilidade, desenvolvido com HTML, CSS e JavaScript puro.

## 📁 Estrutura do Projeto

```
contabilizei-layout/
├── index.html          # Página principal
├── style.css           # Estilos CSS
├── script.js           # Funcionalidades JavaScript
└── README.md           # Documentação
```

## 🚀 Funcionalidades

### Layout Implementado
- ✅ Header com navegação
- ✅ Banner de cookies
- ✅ Seção hero principal
- ✅ Seção MEI (Microempreendedor Individual)
- ✅ Seção de serviços
- ✅ Processo de abertura de empresa
- ✅ Planos e preços
- ✅ Cidades atendidas
- ✅ FAQ (Perguntas Frequentes)
- ✅ Depoimentos de clientes
- ✅ Estatísticas
- ✅ Call-to-action final
- ✅ Footer completo
- ✅ Botão flutuante do WhatsApp

### Funcionalidades JavaScript
- ✅ Banner de cookies com localStorage
- ✅ Navegação mobile responsiva
- ✅ FAQ interativo
- ✅ Sistema de abas
- ✅ Scroll suave
- ✅ Integração WhatsApp
- ✅ Animações de entrada

## 🎨 Design

### Cores Principais
- **Verde Primário**: #00D4AA
- **Verde Secundário**: #00B894
- **Azul Escuro**: #2D3748
- **Cinza Claro**: #F7FAFC

### Tipografia
- Fonte principal: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
- Hierarquia tipográfica bem definida
- Tamanhos responsivos

### Layout Responsivo
- ✅ Desktop (1200px+)
- ✅ Tablet (768px - 1199px)
- ✅ Mobile (até 767px)

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Estilos modernos com Flexbox e Grid
- **JavaScript ES6+**: Funcionalidades interativas
- **Responsive Design**: Mobile-first approach

## 🚀 Como Usar

1. **Visualização Local**:
   ```bash
   # Abra o arquivo index.html em qualquer navegador
   open index.html
   ```

2. **Servidor Local** (opcional):
   ```bash
   # Com Python
   python -m http.server 8000
   
   # Com Node.js (http-server)
   npx http-server
   ```

3. **Publicação**:
   - Faça upload dos arquivos para qualquer servidor web
   - Compatível com GitHub Pages, Netlify, Vercel, etc.

## 📋 Checklist de Implementação

### HTML
- [x] Estrutura semântica
- [x] Meta tags responsivas
- [x] Acessibilidade (alt, aria-labels)
- [x] SEO básico

### CSS
- [x] Reset CSS
- [x] Variáveis CSS (cores, espaçamentos)
- [x] Flexbox e Grid
- [x] Animações e transições
- [x] Media queries responsivas
- [x] Estados de hover e focus

### JavaScript
- [x] DOM manipulation
- [x] Event listeners
- [x] LocalStorage para cookies
- [x] Smooth scrolling
- [x] Mobile navigation
- [x] FAQ accordion
- [x] Tab switching

## 🔧 Customização

### Cores
Edite as variáveis CSS no início do arquivo `style.css`:

```css
:root {
  --primary-color: #00D4AA;
  --secondary-color: #00B894;
  --dark-color: #2D3748;
  --light-color: #F7FAFC;
}
```

### Conteúdo
- Edite o arquivo `index.html` para alterar textos e imagens
- Substitua as imagens placeholder por imagens reais
- Atualize links e informações de contato

### Funcionalidades
- Modifique `script.js` para adicionar novas funcionalidades
- Integre com APIs reais para formulários
- Adicione analytics e tracking

## 📞 Contato WhatsApp

O botão do WhatsApp está configurado com o número: `554799854490`.

## 📸 Instagram

Link do Instagram: `https://www.instagram.com/sdassessoriacontail?igsh=Y3V1c2o4bzd3MGdr`

## 🌐 Compatibilidade

- ✅ Chrome 60+
- ✅ Firefox 55+
- ✅ Safari 12+
- ✅ Edge 79+
- ✅ Mobile browsers

## 📝 Notas de Desenvolvimento

- Layout fiel ao design original da SIMPLES D+ Contabilidade
- Código limpo e bem comentado
- Estrutura modular para fácil manutenção
- Performance otimizada
- Acessibilidade considerada

## 🚀 Próximos Passos

Para transformar em um site funcional:

1. **Backend Integration**:
   - Formulários de contato
   - Sistema de cadastro
   - Integração com CRM

2. **CMS Integration**:
   - WordPress
   - Strapi
   - Contentful

3. **Performance**:
   - Otimização de imagens
   - Minificação de CSS/JS
   - CDN implementation

4. **Analytics**:
   - Google Analytics
   - Facebook Pixel
   - Hotjar

---

**Desenvolvido como réplica educacional do site da SIMPLES D+ Contabilidade**


